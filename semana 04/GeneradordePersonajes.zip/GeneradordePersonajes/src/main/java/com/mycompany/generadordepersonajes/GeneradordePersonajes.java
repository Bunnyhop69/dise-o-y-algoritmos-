public class Main {

    public static void main(String[] args) {

        CreadorPersonaje creador = new CreadorPersonaje();

        Personaje guerrero =
                creador.crearPersonaje("GUERRERO");

        Personaje mago =
                creador.crearPersonaje("MAGO");

        Personaje arquero =
                creador.crearPersonaje("ARQUERO");

        guerrero.crear();
        mago.crear();
        arquero.crear();
    }
}
