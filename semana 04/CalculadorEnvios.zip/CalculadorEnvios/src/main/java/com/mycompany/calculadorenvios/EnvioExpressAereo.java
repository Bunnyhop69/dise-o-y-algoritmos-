/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.calculadorenvios;

public class EnvioExpressAereo implements EstrategiaEnvio {

    @Override
    public double calcularTarifa(double peso, double distancia) {

        return (peso * 5.5) + (distancia * 0.8);
    }
}
