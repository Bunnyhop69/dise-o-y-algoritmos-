
package com.mycompany.calculadorenvios;


public class EnvioMaritimoInternacional
        implements EstrategiaEnvio {

    @Override
    public double calcularTarifa(double peso, double distancia) {

        return (peso * 0.9) + 150.0;
    }
}