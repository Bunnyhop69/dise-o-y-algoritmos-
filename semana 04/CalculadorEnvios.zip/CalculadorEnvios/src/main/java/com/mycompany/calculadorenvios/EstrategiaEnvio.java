package com.mycompany.calculadorenvios;

public interface EstrategiaEnvio {

    double calcularTarifa(double peso, double distancia);
}
