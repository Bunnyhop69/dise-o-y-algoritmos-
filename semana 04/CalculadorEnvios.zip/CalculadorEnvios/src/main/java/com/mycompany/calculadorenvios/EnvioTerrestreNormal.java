
package com.mycompany.calculadorenvios;


public class EnvioTerrestreNormal implements EstrategiaEnvio {

    @Override
    public double calcularTarifa(double peso, double distancia) {

        return (peso * 1.5) + (distancia * 0.2);
    }
}