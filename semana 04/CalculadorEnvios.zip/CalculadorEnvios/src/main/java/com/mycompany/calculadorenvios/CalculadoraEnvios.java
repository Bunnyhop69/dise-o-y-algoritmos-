
package com.mycompany.calculadorenvios;

public class CalculadoraEnvios {

    private EstrategiaEnvio estrategia;

    public CalculadoraEnvios(EstrategiaEnvio estrategia) {
        this.estrategia = estrategia;
    }

    public void cambiarEstrategia(EstrategiaEnvio estrategia) {
        this.estrategia = estrategia;
    }

    public double calcular(double peso, double distancia) {

        return estrategia.calcularTarifa(peso, distancia);
    }
}
