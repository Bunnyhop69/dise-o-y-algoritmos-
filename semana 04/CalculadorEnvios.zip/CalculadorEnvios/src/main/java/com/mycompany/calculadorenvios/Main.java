package com.mycompany.calculadorenvios;


public class Main {

    public static void main(String[] args) {

        double peso = 10;
        double distancia = 100;

        CalculadoraEnvios calculadora =
                new CalculadoraEnvios(
                    new EnvioExpressAereo()
                );

        System.out.println(
            "Express aéreo: "
            + calculadora.calcular(peso, distancia)
        );

        calculadora.cambiarEstrategia(
            new EnvioTerrestreNormal()
        );

        System.out.println(
            "Terrestre normal: "
            + calculadora.calcular(peso, distancia)
        );

        calculadora.cambiarEstrategia(
            new EnvioMaritimoInternacional()
        );

        System.out.println(
            "Marítimo internacional: "
            + calculadora.calcular(peso, distancia)
        );
    }
}
