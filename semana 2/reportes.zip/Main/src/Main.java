public class Main {
    public static void main(String[] args) {
        ServicioReportes servicio = new ServicioReportes();

        GeneradorReporte pdf = new GeneradorPDF();
        GeneradorReporte excel = new GeneradorExcel();
        GeneradorReporte csv = new GeneradorCSV();
        GeneradorReporte html = new GeneradorHTML();

        servicio.ejecutar(pdf);
        servicio.ejecutar(excel);
        servicio.ejecutar(csv);
        servicio.ejecutar(html);
    }
}
