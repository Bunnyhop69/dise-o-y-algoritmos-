class GeneradorExcel implements GeneradorReporte {
    @Override
    public void generar() {
        System.out.println("Generando reporte en formato Excel...");
    }
}