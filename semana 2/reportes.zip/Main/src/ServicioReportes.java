class ServicioReportes {
    public void ejecutar(GeneradorReporte generador) {
        generador.generar();
    }
}
