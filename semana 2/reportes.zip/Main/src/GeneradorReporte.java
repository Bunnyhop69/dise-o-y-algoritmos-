interface GeneradorReporte {
    void generar();
}