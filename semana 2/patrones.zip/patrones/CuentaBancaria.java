public class CuentaBancaria {
  protected String titular;
    protected double saldo;

    public CuentaBancaria(String titular, double saldo) {
        this.titular = titular;
        this.saldo = saldo;
    }

    public void depositar(double monto) {
        saldo += monto;
        System.out.println("Depósito realizado: " + monto);
    }

    public double consultarSaldo() {
        return saldo;
    }  
}
