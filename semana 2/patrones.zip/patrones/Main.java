public class Main {
    public static void main(String[] args) {

        CuentaAhorros ahorro = new CuentaAhorros("Juan", 1000);
        ahorro.retirar(200);

        CuentaPlazoFijo plazo = new CuentaPlazoFijo("Ana", 2000);
        plazo.retirarAlVencimiento(500);
    }
}
