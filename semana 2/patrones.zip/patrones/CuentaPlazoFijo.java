public class CuentaPlazoFijo extends CuentaBancaria {

    public CuentaPlazoFijo(String titular, double saldo) {
        super(titular, saldo);
    }

    public void retirarAlVencimiento(double monto) {
        saldo -= monto;
        System.out.println("Retiro al vencimiento: " + monto);
    }
}