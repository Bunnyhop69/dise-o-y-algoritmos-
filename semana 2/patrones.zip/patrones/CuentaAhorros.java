public class CuentaAhorros extends CuentaBancaria implements Retirable {

    public CuentaAhorros(String titular, double saldo) {
        super(titular, saldo);
    }

    @Override
    public void retirar(double monto) {
        saldo -= monto;
        System.out.println("Retiro realizado: " + monto);
    }
}