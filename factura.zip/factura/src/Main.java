public class Main {

    public static void main(String[] args) {

        Usuario usuario = new Usuario(
                "Juan Pérez",
                "juan@gmail.com"
        );

        ValidadorUsuario validador = new ValidadorUsuario();
        UsuarioRepository repository = new UsuarioRepository();
        NotificadorUsuario notificador = new NotificadorUsuario();

        UsuarioService service = new UsuarioService(
                validador,
                repository,
                notificador
        );

        service.registrarUsuario(usuario);
    }
}
