public class UsuarioService {

    private ValidadorUsuario validador;
    private UsuarioRepository repository;
    private NotificadorUsuario notificador;

    public UsuarioService(
            ValidadorUsuario validador,
            UsuarioRepository repository,
            NotificadorUsuario notificador) {

        this.validador = validador;
        this.repository = repository;
        this.notificador = notificador;
    }

    public void registrarUsuario(Usuario usuario) {

        if (!validador.validar(usuario)) {
            return;
        }

        repository.guardar(usuario);

        notificador.notificar(usuario);

        System.out.println("Usuario registrado correctamente.");
    }
}
