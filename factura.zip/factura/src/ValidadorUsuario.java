public class ValidadorUsuario {

    public boolean validar(Usuario usuario) {

        if (usuario.getNombre() == null || usuario.getNombre().isEmpty()) {
            System.out.println("Error: el nombre es obligatorio.");
            return false;
        }

        if (usuario.getCorreo() == null || !usuario.getCorreo().contains("@")) {
            System.out.println("Error: el correo no es válido.");
            return false;
        }

        return true;
    }
}