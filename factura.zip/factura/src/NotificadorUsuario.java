public class NotificadorUsuario {

    public void notificar(Usuario usuario) {

        System.out.println(
                "Enviando SMS a " + usuario.getCorreo()
        );
    }
}