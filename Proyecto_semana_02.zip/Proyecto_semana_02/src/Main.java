//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        CalculadoraEnvio calculadora = new CalculadoraEnvio();

        MetodoEnvio moto = new EnvioMoto();
        MetodoEnvio auto = new EnvioAuto();
        MetodoEnvio camion = new EnvioCamion();
        MetodoEnvio dron = new EnvioDron();

        double peso = 10;

        System.out.println("Envío en Moto: S/ " +
                calculadora.calcular(moto, peso));

        System.out.println("Envío en Auto: S/ " +
                calculadora.calcular(auto, peso));

        System.out.println("Envío en Camión: S/ " +
                calculadora.calcular(camion, peso));

        System.out.println("Envío en Dron: S/ " +
                calculadora.calcular(dron, peso));

    }
}